import funciones_crear_tableros as funct
import funciones_ataques as funat

tablero_usuario = {'A': {1: 'agua', 2: 'barco'}, 'B': {1: 'agua', 2: 'agua'}}
tablero_usuario2 = tablero_oponente2 = tablero_oponente1 = tablero_usuario.copy()
funct.colocar_barcos(tablero_usuario, "A", 1, "+", 2, "numeros", [], True)
print(tablero_usuario)
# Se ve visualmente que cambia el A1 y A2 por barcos en color

print(funat.is_hundido(["A1**", "A2**"])) # Hundido
print(funat.is_hundido(["A1**", "A2"])) # No hundido